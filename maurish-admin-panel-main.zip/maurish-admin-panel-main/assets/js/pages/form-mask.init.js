$(document).ready(function() {
    $(".input-mask").inputmask()
});