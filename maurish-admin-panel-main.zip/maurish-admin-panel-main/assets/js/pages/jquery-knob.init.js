$(function() {
    $(".knob").knob()
});